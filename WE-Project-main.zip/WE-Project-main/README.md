
# COVID-19 SCREENING TEST

Introduction:

This Project is about Screening test of Covid-19. It asks some questions from you and suggest you whether you need to test covid-19 or keep yourself quarantine or you are well and good.
It also has some other parts which describes what is Covid-19, what are its symptoms and how to prevent it.


## Tools:

While making this app I used some tools which are given Below:

•	HTML (Hypertext Markup Language)

•	CSS (Cascading Style Sheets)

•	JS (JavaScript)

•	Bootstrap


  
## Features

•	When you click the start Button you will reach at some question like do you have fever, and you can click a button yes or no with respect to your situation and further questions asked with you and you give the right answers with respect to your situation after the question answer session ends you will reach at result section which suggest you the result with respect to your answers.

  
## Appendix

Note: For looking in mobile size please right click-->click inspect-->click on mobile size

It can be reloaded for the home page this app didn’t go back.
## Demo

  http://tazeennaz.6te.net/Covid-19%20Project/index.html
  
## Feedback

If you have any feedback, please reach out to me at tazeen.naz20@gmail.com

  